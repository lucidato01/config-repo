package com.co.service.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class GreetingController {
  
	@RequestMapping(
	        value =  "/")
    public ResponseEntity<String> greeting() {
		System.out.println("dasdoaiiasdiasdiasduasduaisduaidsuaiduiaduaoiduaoduao");
        return ResponseEntity.ok("Hola mundo");
    }
}
